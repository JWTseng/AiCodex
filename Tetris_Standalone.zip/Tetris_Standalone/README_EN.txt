Tetris Game - Standalone Version Instructions
============================================

📁 File Description:
- index.html          - Main game file
- tetris.js           - Game logic
- audio.js            - Audio processing
- styles.css          - Style file
- clear-scores.html   - Clear scores page

🚀 How to Start:

Windows Users:
1. Double-click "start_windows.bat"
2. Open browser and visit http://localhost:8000
3. Start playing!

macOS/Linux Users:
1. Double-click "start_mac_linux.sh" or run ./start_mac_linux.sh in terminal
2. Open browser and visit http://localhost:8000
3. Start playing!

⚠️ Requirements:
- Python (Windows) or Python3 (macOS/Linux) must be installed
- Port 8000 must be available
- Modern browser support required (Chrome, Firefox, Safari, Edge)

🎮 Game Controls:
- Arrow Keys: Move blocks
- Spacebar: Quick drop
- P Key: Pause/Resume
- R Key: Restart game

📞 Technical Support:
If you encounter issues, please check:
1. Python is properly installed
2. Firewall is not blocking port 8000
3. Browser supports HTML5

Enjoy the game!
